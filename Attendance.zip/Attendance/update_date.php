<?php

// Read the JSON file and decode it to PHP array
$employees_data = json_decode(file_get_contents('employees.json'), true);

// Get the current date
$current_date = date('Y-m-d');

// Check if the date has changed from the previous day
if ($current_date != $employees_data['last_updated']) {
    // Update the status of all employees to "leave"
    foreach ($employees_data['employees'] as &$employee) {
        $employee['state'] = 'leave';
    }

    // Update the last updated date
    $employees_data['last_updated'] = $current_date;

    // Encode the PHP array back to JSON format
    $json_data = json_encode($employees_data, JSON_PRETTY_PRINT);

    // Write the updated JSON data back to the file
    file_put_contents('employees.json', $json_data);
}

?>