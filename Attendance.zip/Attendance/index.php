<?php
session_start();

// Check if user is already logged in, redirect to main page
if(isset($_SESSION['username'])) {
    header("Location: main.php");
    exit();
}

// Function to authenticate user
function authenticate($username, $password, $employees) {
    foreach ($employees['employees'] as $employee) {
        if ($employee['name'] === $username && $employee['password'] === $password) {
            return true;
        }
    }
    return false;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Read the JSON file and decode it to PHP array
    $employees_data = json_decode(file_get_contents('employees.json'), true);

    // Authenticate user
    if (authenticate($username, $password, $employees_data)) {
        // Authentication successful, set session variables
        $_SESSION['username'] = $username;
        include 'update_date.php';
        header("Location: main.php");
        exit();
    } else {
        // Authentication failed, display error message
        $error_message = "ユーザー名かパスワードが無効！";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <!-- Include CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
    <div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form class="login100-form validate-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
					<span class="login100-form-title p-b-49">
						ログイン
					</span>
                    <?php if(isset($error_message)) { ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $error_message; ?>
                        </div>
                    <?php } ?>
					<div class="wrap-input100 validate-input m-b-23" data-validate = "ユーザーIDが必要です。">
						<span class="label-input100">ユーザーID</span>
						<input type="text" class="input100" id="username" name="username" required placeholder="ユーザーIDを入力します。">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="パスワードが必要です。">
						<span class="label-input100">パスワード</span>
						<input type="password" class="input100" id="password" name="password" required placeholder="パスワードを入力します。">
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
					<div class="text-right p-t-8 p-b-31">
					</div>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button type="submit" class="login100-form-btn">
								ログイン
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>