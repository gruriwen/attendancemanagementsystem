<?php

if (isset($_POST['select_state'])) {
    $new_state = $_POST['state'];

    // Read the JSON file and decode it to PHP array
    $employees_data = json_decode(file_get_contents('employees.json'), true);

    // Find the index of the employee whose state needs to be updated based on the logged-in user
    $employee_index = array_search($_SESSION['username'], array_column($employees_data['employees'], 'name'));

    // Update the state of the employee
    $employees_data['employees'][$employee_index]['state'] = $new_state;

    // Encode the PHP array back to JSON format
    $json_data = json_encode($employees_data, JSON_PRETTY_PRINT);

    // Write the updated JSON data back to the file
    file_put_contents('employees.json', $json_data);

    // Redirect back to main page
    header("Location: main.php");
    exit();
}
?>

