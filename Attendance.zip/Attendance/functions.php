<?php

function getEmployeesByState($state) {
    $employees = json_decode(file_get_contents('employees.json'), true);
    $filteredEmployees = array_filter($employees['employees'], function($employee) use ($state) {
        return $employee['state'] === $state;
    });
    return $filteredEmployees;
}

function getEmployeesByName($userid) {
    $employees = json_decode(file_get_contents('employees.json'), true);
    $filteredEmployees = array_filter($employees['employees'], function($employee) use ($userid) {
        return $employee['name'] === $userid;
    });
    return $filteredEmployees;
}


function getAllEmployees() {
    $employees = json_decode(file_get_contents('employees.json'), true);
    return $employees['employees'];
}

?>