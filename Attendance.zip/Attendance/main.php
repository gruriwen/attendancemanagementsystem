<?php
session_start();
include 'functions.php';

// Check if user is not logged in, redirect to login page
if(!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Handle logout
if(isset($_POST['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

$userid = $_SESSION['username'];
$employeeName = getEmployeesByName($userid);
// Default state is 'All' if not provided in URL
$state = isset($_GET['state']) ? $_GET['state'] : 'all';

// Retrieve employees based on the selected state
if($state === 'all') {
    $employees = getAllEmployees();
} else {
    $employees = getEmployeesByState($state);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Main Page</title>
    <!-- Include CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        
        <div style="display:flex; flex-direction: row; justify-content: space-between; align-items: center; align-content: center;margin-top:20px;">
            <h2 style="font-style: italic;"><?php foreach($employeeName as $realname) {echo $realname['realname'];} ?>さん</h2>
            <form class="form-inline my-2 my-lg-0" method="post">
                <button class="btn btn-danger my-2 my-sm-0" type="submit" name="logout">ログアウト</button>
            </form>
        </div>
        <!-- Navigation bar -->
        <div class="navbar navbar-expand-lg navbar-dark bg-success">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img src="images/logo1.png" style="width:50px;height:50px;"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="?state=all">全て</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="?state=arrive">出社</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="?state=going">離席</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="?state=leaving">外出</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="?state=leave">退社</a>
                        </li>
                    </ul>
                    <div class="d-flex align-items-center">
                        <input class="form-control mr-sm-2" id="myInput" type="text" placeholder="検索...">
                        <div class="ml-3 w-50">
                            <?php
                            $today_date = date('Y-m-d');
                            echo "<span class='text-white '>$today_date</span>";
                            ?>
                        </div>
                        <a class="btn nav-link text-white" data-toggle="modal" data-target="#myModal">
                        <i class="fas fa-user-check" data-toggle="tooltip" data-placement="bottom" title="ステータスを選択してください。"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        

        <!-- The Modal -->
        <div class="modal fade" id="myModal">
            <?php
            include 'select_state.php';
            ?>
            <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
            
                <!-- Modal Header -->
                <div class="modal-header">
                <h4 class="modal-title">ステータスを選択してください。</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                
                <form method="post">
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="d-flex flex-row">
                        <select class="form-control" id="state" name="state" required>
                            <option value="arrive">出社</option>
                            <option value="going">離席</option>
                            <option value="leaving">外出</option>
                            <option value="leave">退社</option>
                        </select>
                    </div>
                </div>
                
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" name="select_state">選択</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">閉まる</button>
                </div>
                </form>
            </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>名前</th>
                        <th>ステータス</th>
                    </tr>
                </thead>
                <tbody id="myTable">
                    <?php foreach($employees as $employee) { ?>
                        <tr>
                            <td class="align-middle"><?php echo $employee['realname'];?></td>
                            <td>
                                <div class="d-flex flex-wrap justify-content-around text-lg">
                                    <?php switch ($employee['state']) {
                                        case 'arrive':?>
                                            <span class="badge badge-pill badge-success p-2 px-4 m-1" style="font-size:14px;">出社</span>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">離席</span>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">外出</span>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">退社</span>
                                        <?php break;
                                        case 'leaving':?>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">出社</span>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">離席</span>
                                            <span class="badge badge-pill badge-danger p-2 px-4 m-1" style="font-size:14px;">外出</span>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">退社</span>
                                        <?php break;
                                        case 'going':?>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">出社</span>
                                            <span class="badge badge-pill badge-warning p-2 px-4 m-1" style="font-size:14px;">離席</span>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">外出</span>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">退社</span>
                                        <?php break;
                                        case 'leave':?>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">出社</span>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">離席</span>
                                            <span class="badge badge-pill badge-light p-2 px-4 m-1" style="font-size:14px;">外出</span>
                                            <span class="badge badge-pill badge-dark p-2 px-4 m-1" style="font-size:14px;">退社</span>
                                        <?php break;
                                        default:?>
                                            <span class="badge badge-pill badge-success p-2 px-4 m-1" style="font-size:14px;">出社</span>
                                            <span class="badge badge-pill badge-warning p-2 px-4 m-1" style="font-size:14px;">離席</span>
                                            <span class="badge badge-pill badge-danger p-2 px-4 m-1" style="font-size:14px;">外出</span>
                                            <span class="badge badge-pill badge-dark p-2 px-4 m-1" style="font-size:14px;">退社</span>
                                    <?php }?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <!-- Content area -->
        
    </div>

    <script>
    $(document).ready(function(){
        $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
        $('[data-toggle="tooltip"]').tooltip(); 
    });
    </script>
</body>
</html>